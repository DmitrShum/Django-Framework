from authapp.models import ShopUser
from django.contrib import admin

admin.site.register(ShopUser)
