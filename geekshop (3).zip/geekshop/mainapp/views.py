from django.shortcuts import render
from django.conf import settings
import json
import os
from mainapp.models import Product, ProductCategory


#Create your views here.



def main(request):
    title = 'главня'
    products = Product.objects.all()[:4]
    content = {'title': title, 'products': products}
    return render(request, 'mainapp/index.html', content)

def products(request, pk = None):
    links_menu = ProductCategory.objects.all()
    same_products = Product.objects.all()[:4]
    content = {
        'title': 'Продукты',
        'same_products': same_products,
        'links_menu' : links_menu
    }
    return render(request, 'mainapp/products.html', content)

def contact(request):
    title = 'о нас'
    locations = []
    with open(os.path.join(settings.BASE_DIR, 'contacts.json')) as f:
        locations = json.load(f)
    content = {'title': title, 'locations': locations}
    return render(request, 'mainapp/contact.html', content)
